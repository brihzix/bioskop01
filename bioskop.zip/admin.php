<?php
?>
<!DOCTYPE html>
Action :<br>
<p style="text-indent: 0.5in; line-height:70%;"><a href='add_balance.php'>Tambah Balance User</a></p> 
<p style="text-indent: 0.5in; line-height:70%;"><a href='film_create.php'>Tambah Film</a></p>
<p style="text-indent: 0.5in; line-height:70%;"><a href='jadwal_create.php'>Tambah Jadwal</a></p>
<p style="text-indent: 0.5in; line-height:70%;"><a href='regist_user.php'>Register User</a></p>
<p style="text-indent: 0.5in; line-height:70%;"><a href='my_tiket.php'>Laporan Pemesanan Tiket</a></p>