	<footer>
	<div class='span12'>
	<div class="well" style='background:url(<?PHP echo "bootstrap/body7.png"; ?>) fixed center;'>
	<center style='color:white'>&copy; <a href='#'>Information System</a> <?PHP echo date('Y'); ?> All Right Reserved - Create By <a href='#'>Kelompok awak</a></center><a href='#' class='pull-right icon_megasoft' style='margin-top:-25px;' title='Information System'></a></a>
	</div>
	</div>
	</footer>